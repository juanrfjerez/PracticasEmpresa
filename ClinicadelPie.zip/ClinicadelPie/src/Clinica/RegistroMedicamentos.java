package Clinica;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class RegistroMedicamentos extends JPanel {

    private JTextField txtBuscar, txtNombre, txtCantidad, txtCaducidad;
    private DefaultTableModel modeloTabla;
    private JTable tablaMedicamentos;
    private List<Object[]> listaMedicamentos = new ArrayList<>();

    public RegistroMedicamentos() {
        setLayout(new BorderLayout(10, 10));

        // PANEL BÚSQUEDA SUPERIOR
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtBuscar = new JTextField(25);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        txtBuscar.setToolTipText("Buscar medicamento...");
        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filtrarTabla(txtBuscar.getText());
            }
        });
        panelBusqueda.add(new JLabel("🔍 Buscar:"));
        panelBusqueda.add(txtBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // PANEL CENTRAL (formulario + tabla)
        JPanel panelCentro = new JPanel(new BorderLayout(10, 10));

        // FORMULARIO HORIZONTAL
        JPanel panelFormulario = new JPanel(new BorderLayout());

        // Subpanel izquierda (Nombre)
        JPanel panelIzq = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtNombre = new JTextField();
        txtNombre.setPreferredSize(new Dimension(160, 25));
        panelIzq.add(new JLabel("Nombre Medicamento:"));
        panelIzq.add(txtNombre);

        // Subpanel centro (Cantidad)
        JPanel panelCentroForm = new JPanel(new FlowLayout(FlowLayout.CENTER));
        txtCantidad = new JTextField();
        txtCantidad.setPreferredSize(new Dimension(80, 25));
        panelCentroForm.add(new JLabel("Cantidad:"));
        panelCentroForm.add(txtCantidad);

        // Subpanel derecha (Caducidad + botón)
        JPanel panelDer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        txtCaducidad = new JTextField();
        txtCaducidad.setPreferredSize(new Dimension(130, 25));
        JButton btnAgregar = new JButton("➕ Añadir");
        btnAgregar.addActionListener(e -> agregarMedicamento());
        panelDer.add(new JLabel("Caducidad:"));
        panelDer.add(txtCaducidad);
        panelDer.add(btnAgregar);

        panelFormulario.add(panelIzq, BorderLayout.WEST);
        panelFormulario.add(panelCentroForm, BorderLayout.CENTER);
        panelFormulario.add(panelDer, BorderLayout.EAST);

        panelCentro.add(panelFormulario, BorderLayout.NORTH);

        // TABLA
        modeloTabla = new DefaultTableModel(new String[]{"Nombre del Medicamento", "Cantidad", "Caducidad"}, 0);
        tablaMedicamentos = new JTable(modeloTabla);
        tablaMedicamentos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaMedicamentos.setRowHeight(20);
        panelCentro.add(new JScrollPane(tablaMedicamentos), BorderLayout.CENTER);

        add(panelCentro, BorderLayout.CENTER);

        // BOTÓN VOLVER ABAJO
        JButton btnVolver = new JButton("⬅ Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN); // Color llamativo original
        btnVolver.setForeground(Color.BLACK); // Texto oscuro para contraste
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });

        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelVolver.add(btnVolver);
        add(panelVolver, BorderLayout.SOUTH);

    }

    private void agregarMedicamento() {
        String nombre = txtNombre.getText().trim();
        String cantidad = txtCantidad.getText().trim();
        String caducidad = txtCaducidad.getText().trim();

        if (!nombre.isEmpty() && !cantidad.isEmpty() && !caducidad.isEmpty()) {
            Object[] fila = new Object[]{nombre, cantidad, caducidad};
            listaMedicamentos.add(fila);
            modeloTabla.addRow(fila);
            limpiarFormulario();
        } else {
            JOptionPane.showMessageDialog(this, "Rellena todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCantidad.setText("");
        txtCaducidad.setText("");
    }

    private void filtrarTabla(String texto) {
        modeloTabla.setRowCount(0);
        for (Object[] fila : listaMedicamentos) {
            if (fila[0].toString().toLowerCase().contains(texto.toLowerCase())) {
                modeloTabla.addRow(fila);
            }
        }
    }
}






