package Clinica;

import java.awt.*;
import javax.swing.*;

public class RegistroMedicamentos extends JPanel {

    public RegistroMedicamentos() {
        setLayout(new BorderLayout());
        
        JLabel etiqueta = new JLabel("Esta es la plantilla de Registro de Medicamentos", SwingConstants.CENTER);
        etiqueta.setFont(new Font("Arial", Font.PLAIN, 18));
        add(etiqueta, BorderLayout.CENTER);

        // Botón Volver
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN); // Color llamativo
        btnVolver.setForeground(Color.BLACK); // Texto oscuro para contraste
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            // Volver a la pantalla principal
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });

        // Panel con botón "Volver"
        JPanel panelVolver = new JPanel();
        panelVolver.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelVolver.add(btnVolver);
        add(panelVolver, BorderLayout.SOUTH);
    }
}


