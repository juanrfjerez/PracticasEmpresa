package Clinica;

import java.awt.*;
import java.net.URL;
import javax.swing.*;

public class PaginaPrincipal extends JFrame {
    private CardLayout cardLayout;
    private JPanel panelContenedor;
    private ListaPacientes listaPacientes;

    public PaginaPrincipal() {
        setTitle("Clínica del Pie Vanesa Pinto");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Pantalla completa
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false);

        // Título con logo
        JLabel titulo = new JLabel();
        try {
            URL url = new URL("https://clinicadelpievanesapinto.es/wp-content/uploads/2022/07/Logo-Pinto-sin-fondo-ni-direccion.pdf-e1658481562665-1024x158.png");
            ImageIcon imageIcon = new ImageIcon(url);
            titulo.setIcon(imageIcon);
        } catch (Exception e) {
            e.printStackTrace();
        }
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 10));
        add(titulo, BorderLayout.NORTH);

        // Layout para paneles
        cardLayout = new CardLayout();
        panelContenedor = new JPanel(cardLayout);

        // Panel principal con botones
        JPanel panelPrincipal = new JPanel(new GridLayout(2, 2, 30, 30));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Botones
        JButton btnRegistroMedicamentos = new JButton("<html><center><b>REGISTRO<br>DE MEDICAMENTOS</b></center></html>");
        btnRegistroMedicamentos.setFont(new Font("Arial", Font.PLAIN, 16));
        btnRegistroMedicamentos.setPreferredSize(new Dimension(150, 100));
        btnRegistroMedicamentos.addActionListener(e -> cardLayout.show(panelContenedor, "RegistroMedicamentos"));

        JButton btnHojaPedidos = new JButton("<html><center><b>HOJA<br>DE PEDIDOS</b></center></html>");
        btnHojaPedidos.setFont(new Font("Arial", Font.PLAIN, 16));
        btnHojaPedidos.setPreferredSize(new Dimension(150, 100));
        btnHojaPedidos.addActionListener(e -> cardLayout.show(panelContenedor, "HojaDePedidos"));

        JButton btnRegistroPacientes = new JButton("<html><center><b>REGISTRO<br>DE PACIENTES</b></center></html>");
        btnRegistroPacientes.setFont(new Font("Arial", Font.PLAIN, 16));
        btnRegistroPacientes.setPreferredSize(new Dimension(150, 100));
        btnRegistroPacientes.addActionListener(e -> cardLayout.show(panelContenedor, "RegistroPacientes"));

        JButton btnListaPacientes = new JButton("<html><center><b>LISTA<br>DE PACIENTES</b></center></html>");
        btnListaPacientes.setFont(new Font("Arial", Font.PLAIN, 16));
        btnListaPacientes.setPreferredSize(new Dimension(150, 100));
        btnListaPacientes.addActionListener(e -> cardLayout.show(panelContenedor, "ListaPacientes"));

        // Añadir botones al panel principal
        panelPrincipal.add(btnRegistroMedicamentos);
        panelPrincipal.add(btnHojaPedidos);
        panelPrincipal.add(btnRegistroPacientes);
        panelPrincipal.add(btnListaPacientes);

        // Paneles adicionales
        panelContenedor.add(panelPrincipal, "Inicio");
        panelContenedor.add(new RegistroMedicamentos(), "RegistroMedicamentos");
        panelContenedor.add(new HojaDePedidos(), "HojaDePedidos");
        panelContenedor.add(new RegistroPacientes(), "RegistroPacientes");

        // ListaPacientes se crea una vez y se puede acceder para añadir datos más adelante
        listaPacientes = new ListaPacientes();
        panelContenedor.add(listaPacientes, "ListaPacientes");

        add(panelContenedor, BorderLayout.CENTER);

        // Footer vacío
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.WHITE);
        add(footerPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PaginaPrincipal().setVisible(true));
    }
}








