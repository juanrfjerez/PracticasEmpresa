package Clinica;

import java.awt.*;
import java.net.URL;
import javax.swing.*;

public class PaginaPrincipal extends JFrame {
    private CardLayout cardLayout;  // Usamos CardLayout para manejar múltiples paneles
    private JPanel panelContenedor;  // Panel contenedor donde se cambiará el contenido

    public PaginaPrincipal() {
        setTitle("Clínica del Pie Vanesa Pinto");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Abrir en pantalla completa
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(false); 

        // Panel de Título con Imagen
        JLabel titulo = new JLabel();
        try {
            // Usamos una URL para cargar la imagen (la URL de ejemplo puede ser reemplazada por la local si lo deseas)
            URL url = new URL("https://clinicadelpievanesapinto.es/wp-content/uploads/2022/07/Logo-Pinto-sin-fondo-ni-direccion.pdf-e1658481562665-1024x158.png");
            ImageIcon imageIcon = new ImageIcon(url);
            titulo.setIcon(imageIcon);
        } catch (Exception e) {
            e.printStackTrace(); // Si la imagen no se carga, muestra el error
        }

        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 10));
        add(titulo, BorderLayout.NORTH);

        // Panel contenedor con CardLayout
        cardLayout = new CardLayout();
        panelContenedor = new JPanel(cardLayout);

        // Panel principal con botones
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new GridLayout(1, 2, 30, 0));  // Coloca los botones en dos columnas
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Botón de Registro de Medicamentos (más pequeño)
        JButton btnRegistro = new JButton("<html><center><b>REGISTRO<br>DE MEDICAMENTOS</b></center></html>");
        btnRegistro.setFont(new Font("Arial", Font.PLAIN, 16));  // Tamaño de fuente reducido
        btnRegistro.setPreferredSize(new Dimension(150, 100));  // Tamaño de los botones reducido
        btnRegistro.addActionListener(e -> cardLayout.show(panelContenedor, "RegistroMedicamentos"));

        // Botón de Hoja de Pedidos (más pequeño)
        JButton btnHojaPedidos = new JButton("<html><center><b>HOJA<br>DE PEDIDOS</b></center></html>");
        btnHojaPedidos.setFont(new Font("Arial", Font.PLAIN, 16));  // Tamaño de fuente reducido
        btnHojaPedidos.setPreferredSize(new Dimension(150, 100));  // Tamaño de los botones reducido
        btnHojaPedidos.addActionListener(e -> cardLayout.show(panelContenedor, "HojaDePedidos"));

        panelPrincipal.add(btnRegistro);
        panelPrincipal.add(btnHojaPedidos);

        // Panel contenedor donde cambiaremos los contenidos
        panelContenedor.add(panelPrincipal, "Inicio");
        panelContenedor.add(new RegistroMedicamentos(), "RegistroMedicamentos");
        panelContenedor.add(new HojaDePedidos(), "HojaDePedidos");

        add(panelContenedor, BorderLayout.CENTER);  // Panel de los botones

        // Añadir un espacio vacío en el fondo si se desea colocar más contenido
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.WHITE);  // Color de fondo opcional
        add(footerPanel, BorderLayout.SOUTH);  // Añadir el panel vacío en la parte inferior
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PaginaPrincipal().setVisible(true));
    }
}




