package Clinica;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

public class HojaDePedidos extends JPanel {
    private JTextField txtMedicamento, txtViaAdmin, txtCantidad;
    private JTable tablaPedidos;
    private DefaultTableModel modeloTabla;

    public HojaDePedidos() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Hoja de Pedidos");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 36));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(lblTitulo);

        JPanel panelDatos = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelDatos.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtMedicamento = new JTextField(10);
        txtViaAdmin = new JTextField(10);
        txtCantidad = new JTextField(5);
        JButton btnAgregar = new JButton("Agregar Pedido");

        JButton btnDescargar = new JButton("Descargar Pedido");
        btnDescargar.setBackground(Color.BLUE);
        btnDescargar.setForeground(Color.WHITE);

        JButton btnEliminarTodo = new JButton("Eliminar Todo");
        btnEliminarTodo.setBackground(Color.RED);
        btnEliminarTodo.setForeground(Color.WHITE);
        btnEliminarTodo.setFocusPainted(false);

        btnEliminarTodo.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar todos los pedidos?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                modeloTabla.setRowCount(0);
            }
        });

        panelDatos.add(new JLabel("Medicamento:"));
        panelDatos.add(txtMedicamento);
        panelDatos.add(new JLabel("Vía de Administración:"));
        panelDatos.add(txtViaAdmin);
        panelDatos.add(new JLabel("Cantidad:"));
        panelDatos.add(txtCantidad);
        panelDatos.add(btnAgregar);
        add(panelDatos);

        JPanel panelDescargar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDescargar.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        panelDescargar.add(btnDescargar);
        panelDescargar.add(btnEliminarTodo); // Se agrega el botón de eliminar todo
        add(panelDescargar);

        String[] columnNames = {"Medicamento", "Vía de Administración", "Cantidad", ""};
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        tablaPedidos = new JTable(modeloTabla);
        tablaPedidos.setRowHeight(30);
        tablaPedidos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaPedidos.getColumnModel().getColumn(3).setPreferredWidth(60);
        tablaPedidos.getColumnModel().getColumn(3).setMaxWidth(60);
        tablaPedidos.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        tablaPedidos.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelTabla.add(new JScrollPane(tablaPedidos), BorderLayout.CENTER);
        add(panelTabla);

        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Centramos el botón
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });
        panelVolver.add(btnVolver);
        add(panelVolver);

        btnAgregar.addActionListener(e -> agregarPedido());

        btnDescargar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Funcionalidad para descargar pedidos no implementada.");
        });
    }

    private void agregarPedido() {
        String medicamento = txtMedicamento.getText().trim();
        String viaAdmin = txtViaAdmin.getText().trim();
        String cantidadStr = txtCantidad.getText().trim();

        if (medicamento.isEmpty() || viaAdmin.isEmpty() || cantidadStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        try {
            int cantidad = Integer.parseInt(cantidadStr);
            modeloTabla.addRow(new Object[]{medicamento, viaAdmin, cantidad, "🗑"});
            txtMedicamento.setText("");
            txtViaAdmin.setText("");
            txtCantidad.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero.");
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setForeground(Color.WHITE);
            setBackground(Color.RED);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            setText(value == null ? "🗑" : value.toString());
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setForeground(Color.WHITE);
            button.setBackground(Color.RED);
            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            label = (value == null) ? "🗑" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (isPushed) {
                int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar este pedido?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    modeloTabla.removeRow(selectedRow);
                }
            }
            isPushed = false;
            return label;
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
}