package Clinica;

import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*; 
import javax.swing.table.*;

public class RegistroMedicamentos extends JPanel { 
    private JTextField txtBuscar, txtNombre, txtCantidad, txtCaducidad; 
    private DefaultTableModel modeloTabla; 
    private JTable tablaMedicamentos; 
    private List<Object[]> listaMedicamentos = new ArrayList<>();
    public RegistroMedicamentos() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); // Configuración vertical para el diseño
    
        // TÍTULO
        JLabel lblTitulo = new JLabel("Registro de Medicamentos");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 36));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(lblTitulo);
    
        // PANEL DE BÚSQUEDA
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        txtBuscar = new JTextField(20);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        txtBuscar.setToolTipText("Buscar medicamento...");
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        btnBuscar.addActionListener(e -> filtrarTabla(txtBuscar.getText()));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        add(panelBusqueda);
    
        // PANEL DE AÑADIR MEDICAMENTOS
        JPanel panelDatos = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        txtNombre = new JTextField(10);
        txtCantidad = new JTextField(5);
        txtCaducidad = new JTextField(10);
        JButton btnAgregar = new JButton("➕ Añadir");
        btnAgregar.addActionListener(e -> agregarMedicamento());
        JButton btnEliminarTodo = new JButton("Eliminar Todo");
        btnEliminarTodo.setBackground(Color.RED);
        btnEliminarTodo.setForeground(Color.WHITE);
        btnEliminarTodo.setFocusPainted(false);
        btnEliminarTodo.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres eliminar todos los medicamentos?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                listaMedicamentos.clear();
                modeloTabla.setRowCount(0);
            }
        });
    
        panelDatos.add(new JLabel("Nombre:"));
        panelDatos.add(txtNombre);
        panelDatos.add(new JLabel("Cantidad:"));
        panelDatos.add(txtCantidad);
        panelDatos.add(new JLabel("Caducidad:"));
        panelDatos.add(txtCaducidad);
        panelDatos.add(btnAgregar);
        panelDatos.add(btnEliminarTodo);
        add(panelDatos);
    
        // TABLA
        String[] columnNames = {"Nombre", "Cantidad", "Caducidad", ""};
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        tablaMedicamentos = new JTable(modeloTabla);
        tablaMedicamentos.setRowHeight(30);
        tablaMedicamentos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaMedicamentos.getColumnModel().getColumn(3).setPreferredWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setMaxWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        tablaMedicamentos.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));
    
        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelTabla.add(new JScrollPane(tablaMedicamentos), BorderLayout.CENTER);
        add(panelTabla);
    
        // BOTÓN VOLVER
        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER)); 
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });
        panelVolver.add(btnVolver);
        add(panelVolver);
    }
    
    private void agregarMedicamento() {
        String nombre = txtNombre.getText().trim();
        String cantidadStr = txtCantidad.getText().trim();
        String caducidadStr = txtCaducidad.getText().trim();
    
        if (nombre.isEmpty() || cantidadStr.isEmpty() || caducidadStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Rellena todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        int cantidad;
        try {
            cantidad = Integer.parseInt(cantidadStr);
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero positivo.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un número entero.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        if (!esFechaValida(caducidadStr)) {
            JOptionPane.showMessageDialog(this, "La fecha de caducidad debe estar en el formato dd/MM/yyyy.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        Object[] fila = new Object[]{nombre, cantidad, caducidadStr, "🗑"};
        listaMedicamentos.add(fila);
        modeloTabla.addRow(fila);
        limpiarFormulario();
    }
    
    private boolean esFechaValida(String fechaStr) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        formatoFecha.setLenient(false);
        try {
            formatoFecha.parse(fechaStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
    
    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCantidad.setText("");
        txtCaducidad.setText("");
    }
    
    private void filtrarTabla(String texto) {
        modeloTabla.setRowCount(0);
        boolean encontrado = false;
    
        if (!texto.isEmpty()) {
            for (Object[] fila : listaMedicamentos) {
                if (fila[0].toString().toLowerCase().contains(texto.toLowerCase())) {
                    modeloTabla.addRow(new Object[]{fila[0], fila[1], fila[2], "🗑"});
                    encontrado = true;
                }
            }
    
            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "No se han encontrado medicamentos que coincidan con la búsqueda.",
                        "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setForeground(Color.WHITE);
            setBackground(Color.RED);
        }
    
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            setText(value == null ? "🗑" : value.toString());
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;
    
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setForeground(Color.WHITE);
            button.setBackground(Color.RED);
            button.addActionListener(e -> fireEditingStopped());
        }
    
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            label = (value == null) ? "🗑" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }
    
        public Object getCellEditorValue() {
            if (isPushed) {
                int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres borrar este medicamento?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    listaMedicamentos.remove(selectedRow);
                    modeloTabla.removeRow(selectedRow);
                }
            }
            isPushed = false;
            return label;
        }
    
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    
        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
}