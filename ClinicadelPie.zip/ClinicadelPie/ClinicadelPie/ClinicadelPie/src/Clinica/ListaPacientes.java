package Clinica;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class ListaPacientes extends JPanel {
    private JTable tablaPacientes;
    private DefaultTableModel modelo;

    public ListaPacientes() {
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Lista de Pacientes", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Crear la tabla vacía con columnas
        String[] columnas = {
            "Nombre", "Apellidos", "Teléfono", "Correo", "Fecha",
            "Material", "Precio (€)", "Entregado (€)", "Debe (€)"
        };

        modelo = new DefaultTableModel(columnas, 0);  // 0 filas por ahora
        tablaPacientes = new JTable(modelo);
        tablaPacientes.setFont(new Font("Arial", Font.PLAIN, 14));
        tablaPacientes.setRowHeight(25);
        tablaPacientes.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

        JScrollPane scroll = new JScrollPane(tablaPacientes);
        add(scroll, BorderLayout.CENTER);

        // Botón volver
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            Container parent = getParent();
            if (parent.getLayout() instanceof CardLayout) {
                CardLayout cardLayout = (CardLayout) parent.getLayout();
                cardLayout.show(parent, "Inicio");
            }
        });

        JPanel panelVolver = new JPanel();
        panelVolver.add(btnVolver);
        add(panelVolver, BorderLayout.SOUTH);
    }

    // Método para añadir pacientes (más adelante desde la base de datos)
    public void agregarPaciente(Object[] datosPaciente) {
        modelo.addRow(datosPaciente);
    }
}


