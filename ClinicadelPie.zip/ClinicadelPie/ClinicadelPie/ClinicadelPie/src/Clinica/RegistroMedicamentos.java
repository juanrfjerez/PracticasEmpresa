package Clinica;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

public class RegistroMedicamentos extends JPanel {

    private JTextField txtBuscar, txtNombre, txtCantidad, txtCaducidad;
    private DefaultTableModel modeloTabla;
    private JTable tablaMedicamentos;
    private List<Object[]> listaMedicamentos = new ArrayList<>();

    public RegistroMedicamentos() {
        setLayout(new BorderLayout(10, 10));

        // PANEL BÚSQUEDA SUPERIOR
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtBuscar = new JTextField(25);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        txtBuscar.setToolTipText("Buscar medicamento...");
        txtBuscar.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filtrarTabla(txtBuscar.getText());
            }
        });
        panelBusqueda.add(new JLabel("🔍 Buscar:"));
        panelBusqueda.add(txtBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // PANEL CENTRAL (formulario + tabla)
        JPanel panelCentro = new JPanel(new BorderLayout(10, 10));

        // FORMULARIO HORIZONTAL
        JPanel panelFormulario = new JPanel(new BorderLayout());

        JPanel panelIzq = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtNombre = new JTextField();
        txtNombre.setPreferredSize(new Dimension(160, 25));
        panelIzq.add(new JLabel("Nombre Medicamento:"));
        panelIzq.add(txtNombre);

        JPanel panelCentroForm = new JPanel(new FlowLayout(FlowLayout.CENTER));
        txtCantidad = new JTextField();
        txtCantidad.setPreferredSize(new Dimension(80, 25));
        panelCentroForm.add(new JLabel("Cantidad:"));
        panelCentroForm.add(txtCantidad);

        JPanel panelDer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        txtCaducidad = new JTextField();
        txtCaducidad.setPreferredSize(new Dimension(130, 25));
        JButton btnAgregar = new JButton("➕ Añadir");
        btnAgregar.addActionListener(e -> agregarMedicamento());
        panelDer.add(new JLabel("Caducidad:"));
        panelDer.add(txtCaducidad);
        panelDer.add(btnAgregar);

        panelFormulario.add(panelIzq, BorderLayout.WEST);
        panelFormulario.add(panelCentroForm, BorderLayout.CENTER);
        panelFormulario.add(panelDer, BorderLayout.EAST);

        panelCentro.add(panelFormulario, BorderLayout.NORTH);

        // TABLA con botón eliminar
        modeloTabla = new DefaultTableModel(new String[]{"Nombre", "Cantidad", "Caducidad", ""}, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };

        tablaMedicamentos = new JTable(modeloTabla);
        tablaMedicamentos.setRowHeight(30);
        tablaMedicamentos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaMedicamentos.getColumnModel().getColumn(3).setPreferredWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setMaxWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        tablaMedicamentos.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));

        panelCentro.add(new JScrollPane(tablaMedicamentos), BorderLayout.CENTER);

        add(panelCentro, BorderLayout.CENTER);

        // BOTÓN VOLVER ABAJO
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });

        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelVolver.add(btnVolver);
        add(panelVolver, BorderLayout.SOUTH);
    }

    private void agregarMedicamento() {
        String nombre = txtNombre.getText().trim();
        String cantidad = txtCantidad.getText().trim();
        String caducidad = txtCaducidad.getText().trim();

        if (!nombre.isEmpty() && !cantidad.isEmpty() && !caducidad.isEmpty()) {
            Object[] fila = new Object[]{nombre, cantidad, caducidad, "🗑"};
            listaMedicamentos.add(fila);
            modeloTabla.addRow(fila);
            limpiarFormulario();
        } else {
            JOptionPane.showMessageDialog(this, "Rellena todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCantidad.setText("");
        txtCaducidad.setText("");
    }

    private void filtrarTabla(String texto) {
        modeloTabla.setRowCount(0);
        for (Object[] fila : listaMedicamentos) {
            if (fila[0].toString().toLowerCase().contains(texto.toLowerCase())) {
                modeloTabla.addRow(new Object[]{fila[0], fila[1], fila[2], "🗑"});
            }
        }
    }

    // RENDERER DEL BOTÓN
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setForeground(Color.WHITE);
            setBackground(Color.RED);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            setText(value == null ? "🗑" : value.toString());
            return this;
        }
    }

    // EDITOR DEL BOTÓN
    class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private int selectedRow;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setForeground(Color.WHITE);
            button.setBackground(Color.RED);
            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            label = (value == null) ? "🗑" : value.toString();
            button.setText(label);
            isPushed = true;
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (isPushed) {
                int opcion = JOptionPane.showConfirmDialog(null, "¿Seguro que quieres borrar este medicamento?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    listaMedicamentos.remove(selectedRow);
                    modeloTabla.removeRow(selectedRow);
                }
            }
            isPushed = false;
            return label;
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }
}








