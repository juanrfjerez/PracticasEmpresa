package Clinica;

import java.awt.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

public class RegistroMedicamentos extends JPanel {
    private JTextField txtBuscar, txtNombre, txtCantidad, txtCaducidad;
    private DefaultTableModel modeloTabla;
    private JTable tablaMedicamentos;
    private List<Object[]> listaMedicamentos = new ArrayList<>();

    public RegistroMedicamentos() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Registro de Medicamentos");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 36));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(lblTitulo);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        txtBuscar = new JTextField(20);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        txtBuscar.setToolTipText("Buscar medicamento...");

        JButton btnBuscar = new JButton("\uD83D\uDD0D Buscar");
        btnBuscar.setFont(new Font("Arial", Font.BOLD, 12));
        btnBuscar.addActionListener(e -> {
            filtrarTabla(txtBuscar.getText());
            txtBuscar.setText("");
        });

        JButton btnMostrarTodos = new JButton("\uD83D\uDCCB Mostrar todos los medicamentos");
        btnMostrarTodos.setFont(new Font("Arial", Font.BOLD, 12));
        btnMostrarTodos.addActionListener(e -> {
            mostrarTodosLosMedicamentos();
            txtBuscar.setText("");
        });

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnMostrarTodos);
        add(panelBusqueda);

        JPanel panelDatos = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        txtNombre = new JTextField(10);
        txtCantidad = new JTextField(5);
        txtCaducidad = new JTextField(10);
        JButton btnAgregar = new JButton("\u2795 A\u00F1adir");
        btnAgregar.addActionListener(e -> agregarMedicamento());

        JButton btnDescargar = new JButton("Descargar Medicamentos");
        btnDescargar.setBackground(Color.BLUE);
        btnDescargar.setForeground(Color.WHITE);

        JButton btnEliminarTodo = new JButton("Eliminar Todo");
        btnEliminarTodo.setBackground(Color.RED);
        btnEliminarTodo.setForeground(Color.WHITE);
        btnEliminarTodo.setFocusPainted(false);

        btnEliminarTodo.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(null, "\u00BFSeguro que quieres eliminar todos los medicamentos?",
                    "Confirmar eliminaci\u00F3n", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
                medicamentoDAO.eliminarTodosMedicamentos();
                medicamentoDAO.reiniciarAutoIncrement();
                listaMedicamentos.clear();
                modeloTabla.setRowCount(0);
            }
        });

        panelDatos.add(new JLabel("Nombre:"));
        panelDatos.add(txtNombre);
        panelDatos.add(new JLabel("Cantidad:"));
        panelDatos.add(txtCantidad);
        panelDatos.add(new JLabel("Caducidad:"));
        panelDatos.add(txtCaducidad);
        panelDatos.add(btnAgregar);
        panelDatos.add(btnEliminarTodo);
        add(panelDatos);

        JPanel panelDescargar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelDescargar.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        panelDescargar.add(btnDescargar);
        panelDescargar.add(btnEliminarTodo);
        add(panelDescargar);

        String[] columnNames = {"Nombre", "Cantidad", "Caducidad", ""};
        modeloTabla = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        tablaMedicamentos = new JTable(modeloTabla);
        tablaMedicamentos.setRowHeight(30);
        tablaMedicamentos.setFont(new Font("Arial", Font.PLAIN, 12));
        tablaMedicamentos.getColumnModel().getColumn(3).setPreferredWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setMaxWidth(60);
        tablaMedicamentos.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        tablaMedicamentos.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelTabla.add(new JScrollPane(tablaMedicamentos), BorderLayout.CENTER);
        add(panelTabla);

        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btnVolver = new JButton("Volver a la P\u00E1gina Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "Inicio");
        });
        panelVolver.add(btnVolver);
        add(panelVolver);

        btnDescargar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Funcionalidad para descargar medicamentos no implementada.");
        });

        cargarMedicamentosDesdeBaseDeDatos();
    }

    private void cargarMedicamentosDesdeBaseDeDatos() {
        MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
        List<Medicamento> medicamentos = medicamentoDAO.obtenerMedicamentos();

        for (Medicamento med : medicamentos) {
            Object[] fila = new Object[]{med.getNombre(), med.getCantidad(), med.getCaducidad(), "\uD83D\uDDD1"};
            modeloTabla.addRow(fila);
            listaMedicamentos.add(new Object[]{med.getNombre(), med.getCantidad(), med.getCaducidad()});
        }
    }

    private void agregarMedicamento() {
        String nombre = txtNombre.getText().trim();
        String cantidadStr = txtCantidad.getText().trim();
        String caducidadStr = txtCaducidad.getText().trim();

        if (nombre.isEmpty() || cantidadStr.isEmpty() || caducidadStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Rellena todos los campos.", "Campos vac\u00EDos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(cantidadStr);
            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "La cantidad debe ser un n\u00FAmero entero positivo.", "Error de Validaci\u00F3n", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un n\u00FAmero entero.", "Error de Validaci\u00F3n", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!esFechaValida(caducidadStr)) {
            JOptionPane.showMessageDialog(this, "La fecha de caducidad debe estar en el formato dd/MM/yyyy.", "Error de Validaci\u00F3n", JOptionPane.ERROR_MESSAGE);
            return;
        }

        java.sql.Date fechaSQL = null;
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            java.util.Date fechaUtil = formato.parse(caducidadStr);
            fechaSQL = new java.sql.Date(fechaUtil.getTime());
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Error al convertir la fecha.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
        Medicamento nuevoMedicamento = new Medicamento(0, nombre, cantidad, fechaSQL);
        medicamentoDAO.agregarMedicamento(nuevoMedicamento);

        Object[] fila = new Object[]{nombre, cantidad, caducidadStr, "\uD83D\uDDD1"};
        modeloTabla.addRow(fila);
        listaMedicamentos.add(new Object[]{nombre, cantidad, caducidadStr});
        limpiarFormulario();
    }

    private boolean esFechaValida(String fechaStr) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        formatoFecha.setLenient(false);
        try {
            formatoFecha.parse(fechaStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCantidad.setText("");
        txtCaducidad.setText("");
    }

    private void filtrarTabla(String texto) {
        modeloTabla.setRowCount(0);
        boolean encontrado = false;

        if (!texto.isEmpty()) {
            for (Object[] fila : listaMedicamentos) {
                if (fila[0].toString().toLowerCase().contains(texto.toLowerCase())) {
                    modeloTabla.addRow(new Object[]{fila[0], fila[1], fila[2], "\uD83D\uDDD1"});
                    encontrado = true;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "No se han encontrado medicamentos que coincidan con la b\u00FAsqueda.",
                        "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void mostrarTodosLosMedicamentos() {
        modeloTabla.setRowCount(0);
        for (Object[] fila : listaMedicamentos) {
            modeloTabla.addRow(new Object[]{fila[0], fila[1], fila[2], "\uD83D\uDDD1"});
        }
    }

    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setForeground(Color.WHITE);
            setBackground(Color.RED);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        protected JButton boton;
        private String texto;
        private int row;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            boton = new JButton();
            boton.setOpaque(true);
            boton.addActionListener(e -> eliminarMedicamento(row));
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            texto = (value == null) ? "" : value.toString();
            boton.setText(texto);
            return boton;
        }

        private void eliminarMedicamento(int row) {
            int opcion = JOptionPane.showConfirmDialog(null, "\u00BFEst\u00E1s seguro de que quieres eliminar este medicamento?",
                    "Eliminar medicamento", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                String nombre = modeloTabla.getValueAt(row, 0).toString();
                MedicamentoDAO medicamentoDAO = new MedicamentoDAO();
                int idMedicamento = medicamentoDAO.obtenerMedicamentoId(nombre);
                if (medicamentoDAO.eliminarMedicamento(idMedicamento)) {
                    modeloTabla.removeRow(row);
                    listaMedicamentos.remove(row);
                }
            }
        }

        public Object getCellEditorValue() {
            return texto;
        }
    }

    class Medicamento {
        private int idMedicamentos;
        private String nombre;
        private int cantidad;
        private Date caducidad;

        public Medicamento(int idMedicamentos, String nombre, int cantidad, Date caducidad) {
            this.idMedicamentos = idMedicamentos;
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.caducidad = caducidad;
        }

        public int getIdMedicamentos() {
            return idMedicamentos;
        }

        public String getNombre() {
            return nombre;
        }

        public int getCantidad() {
            return cantidad;
        }

        public Date getCaducidad() {
            return caducidad;
        }
    }

    class MedicamentoDAO {
        public List<Medicamento> obtenerMedicamentos() {
            List<Medicamento> medicamentos = new ArrayList<>();
            String sql = "SELECT * FROM medicamentos";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    int id = rs.getInt("idMedicamentos");
                    String nombre = rs.getString("Nombre");
                    int cantidad = rs.getInt("Cantidad");
                    Date caducidad = rs.getDate("Caducidad");

                    medicamentos.add(new Medicamento(id, nombre, cantidad, caducidad));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return medicamentos;
        }

        public boolean agregarMedicamento(Medicamento med) {
            String sql = "INSERT INTO medicamentos (Nombre, Cantidad, Caducidad) VALUES (?, ?, ?)";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, med.getNombre());
                stmt.setInt(2, med.getCantidad());
                stmt.setDate(3, med.getCaducidad());

                int filasAfectadas = stmt.executeUpdate();
                return filasAfectadas > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        public boolean eliminarMedicamento(int idMedicamento) {
            String sql = "DELETE FROM medicamentos WHERE idMedicamentos = ?";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, idMedicamento);
                int filasAfectadas = stmt.executeUpdate();
                return filasAfectadas > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
        }

        public void eliminarTodosMedicamentos() {
            String sql = "DELETE FROM medicamentos";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public void reiniciarAutoIncrement() {
            String sql = "ALTER TABLE medicamentos AUTO_INCREMENT = 1";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public int obtenerMedicamentoId(String nombre) {
            String sql = "SELECT idMedicamentos FROM medicamentos WHERE Nombre = ?";
            try (Connection conn = ConexionDB.conectar();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nombre);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt("idMedicamentos");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return -1;
        }
    }
}
