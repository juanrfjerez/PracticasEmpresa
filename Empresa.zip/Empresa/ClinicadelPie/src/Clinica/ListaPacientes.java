package Clinica;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ListaPacientes extends JPanel {
    private JTable tablaPacientes;
    private DefaultTableModel modelo;

    public ListaPacientes() {
        setLayout(new BorderLayout());

        // Crear un contenedor para el título y el panel de búsqueda
        JPanel panelSuperior = new JPanel(new BorderLayout());

        // Título
        JLabel titulo = new JLabel("Lista de Pacientes", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        panelSuperior.add(titulo, BorderLayout.NORTH);

        // Crear panel de búsqueda con espacio adicional
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBusqueda.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        JTextField txtBuscar = new JTextField(20);
        txtBuscar.setFont(new Font("Arial", Font.PLAIN, 12));
        txtBuscar.setToolTipText("Buscar paciente...");

        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Arial", Font.BOLD, 12));
        btnBuscar.addActionListener(e -> {
            filtrarTabla(txtBuscar.getText());
            txtBuscar.setText(""); // Limpiar campo de búsqueda después
        });

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelSuperior.add(panelBusqueda, BorderLayout.SOUTH);

        // Añadir el contenedor superior al diseño
        add(panelSuperior, BorderLayout.NORTH);

        // Crear la tabla vacía con columnas
        String[] columnas = {
            "Nombre", "Apellidos", "DNI", "Teléfono", "Correo", "Fecha",
            "Material", "Precio (€)", "Entregado (€)", "Debe (€)"
        };

        modelo = new DefaultTableModel(columnas, 0);
        tablaPacientes = new JTable(modelo);
        tablaPacientes.setFont(new Font("Arial", Font.PLAIN, 14));
        tablaPacientes.setRowHeight(25);
        tablaPacientes.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

        JScrollPane scroll = new JScrollPane(tablaPacientes);
        add(scroll, BorderLayout.CENTER);

        // Botón volver
        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            Container parent = getParent();
            if (parent.getLayout() instanceof CardLayout) {
                CardLayout cardLayout = (CardLayout) parent.getLayout();
                cardLayout.show(parent, "Inicio");
            }
        });

        JPanel panelVolver = new JPanel();
        panelVolver.add(btnVolver);
        add(panelVolver, BorderLayout.SOUTH);
    }

    private void filtrarTabla(String texto) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(modelo);
        tablaPacientes.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto)); // Filtro que busca sin distinción de mayúsculas/minúsculas
    }

    // Método para añadir pacientes (más adelante desde la base de datos)
    public void agregarPaciente(Object[] datosPaciente) {
        modelo.addRow(datosPaciente);
    }
}