package Clinica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class RegistroPacientes extends JPanel {
    public RegistroPacientes() {
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Registro de Pacientes", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        add(titulo, BorderLayout.NORTH);

        // Crear campos del formulario
        JTextField txtNombre = new JTextField();
        JTextField txtApellidos = new JTextField();
        JTextField txtDNI = new JTextField();
        JTextField txtTelefono = new JTextField();
        JTextField txtCorreo = new JTextField();
        JTextField txtFecha = new JTextField();
        JTextField txtMaterial = new JTextField();
        JTextField txtPrecio = new JTextField();
        JTextField txtEntregado = new JTextField();
        JTextField txtDebe = new JTextField();
        txtDebe.setEditable(false);

        // Listener para calcular lo que debe
        KeyAdapter recalcularDeuda = new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                try {
                    double precio = Double.parseDouble(txtPrecio.getText());
                    double entregado = Double.parseDouble(txtEntregado.getText());
                    double debe = precio - entregado;
                    txtDebe.setText(String.format("%.2f", debe));
                } catch (NumberFormatException ex) {
                    txtDebe.setText("0.00");
                }
            }
        };
        txtPrecio.addKeyListener(recalcularDeuda);
        txtEntregado.addKeyListener(recalcularDeuda);

        // Panel central con GridBagLayout adaptable
        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;

        Font labelFont = new Font("Arial", Font.PLAIN, 16);
        int fila = 0;

        agregarCampoFormulario(formulario, gbc, fila++, "Nombre:", txtNombre, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Apellidos:", txtApellidos, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "DNI:", txtDNI, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Teléfono:", txtTelefono, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Correo Electrónico:", txtCorreo, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Fecha:", txtFecha, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Material Entregado:", txtMaterial, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Precio del Material (€):", txtPrecio, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Dinero Entregado (€):", txtEntregado, labelFont);
        agregarCampoFormulario(formulario, gbc, fila++, "Dinero que Falta (€):", txtDebe, labelFont);

        // Añadir scroll por si la pantalla es pequeña
        JScrollPane scroll = new JScrollPane(formulario);
        scroll.setBorder(null);
        add(scroll, BorderLayout.CENTER);

        // Panel inferior con botones
        JPanel panelInferior = new JPanel(new BorderLayout());

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(new Font("Arial", Font.BOLD, 16));
        JPanel panelBtnGuardar = new JPanel();
        panelBtnGuardar.add(btnGuardar);
        panelInferior.add(panelBtnGuardar, BorderLayout.NORTH);

        JButton btnVolver = new JButton("Volver a la Página Principal");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 16));
        btnVolver.setBackground(Color.CYAN);
        btnVolver.setForeground(Color.BLACK);
        btnVolver.setFocusPainted(false);
        btnVolver.setPreferredSize(new Dimension(250, 50));
        btnVolver.addActionListener(e -> {
            Container parent = getParent();
            if (parent.getLayout() instanceof CardLayout) {
                CardLayout cardLayout = (CardLayout) parent.getLayout();
                cardLayout.show(parent, "Inicio");
            }
        });

        JPanel panelVolver = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelVolver.add(btnVolver);
        panelInferior.add(panelVolver, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);
    }

    private void agregarCampoFormulario(JPanel panel, GridBagConstraints gbc, int fila, String etiqueta, JComponent campo, Font font) {
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.gridwidth = 1;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        JLabel lbl = new JLabel(etiqueta);
        lbl.setFont(font);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        campo.setFont(font);
        panel.add(campo, gbc);
    }
}





