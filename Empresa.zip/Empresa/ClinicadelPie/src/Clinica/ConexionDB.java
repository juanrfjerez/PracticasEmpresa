package Clinica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConexionDB {

    private static final String URL = "jdbc:mysql://localhost:3306/clinica";
    private static final String USUARIO = "root";
    private static final String CONTRASEÑA = "root";

    public static Connection conectar() {
        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);
            System.out.println("¡Conexión exitosa a la base de datos!");
            return conn;
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el driver JDBC.");
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    // Método para agregar un medicamento
    public static void agregarMedicamento(String nombre, int cantidad, String caducidadStr) {
        // Establecer la conexión
        Connection conexion = conectar();
        if (conexion == null) {
            System.out.println("No se pudo establecer la conexión.");
            return;
        }

        String query = "INSERT INTO medicamentos (nombre, cantidad, caducidad) VALUES (?, ?, ?)";
        try {
            // Convertir la fecha al formato adecuado (yyyy-MM-dd)
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date fecha = sdf.parse(caducidadStr); // Obtener la fecha desde la cadena
            java.sql.Date sqlFecha = new java.sql.Date(fecha.getTime()); // Convertir a java.sql.Date

            PreparedStatement stmt = conexion.prepareStatement(query);
            // Establecer los parámetros de la consulta
            stmt.setString(1, nombre);
            stmt.setInt(2, cantidad);
            stmt.setDate(3, sqlFecha);

            // Ejecutar la consulta
            int filasAfectadas = stmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("Medicamento agregado correctamente.");
            } else {
                System.out.println("No se pudo agregar el medicamento.");
            }

        } catch (SQLException | java.text.ParseException e) {
            e.printStackTrace();
        }
    }

    // Método main solo para prueba de conexión
    public static void main(String[] args) {
        // Aquí no se agrega directamente un medicamento
        // Solo se verifica que la conexión a la base de datos esté funcionando
    }
}
