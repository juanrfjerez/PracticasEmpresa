package Clinica;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDB {
    private static final String URL = "jdbc:mysql://localhost:3306/registro_medicamentos";
    private static final String USUARIO = "root";
    private static final String CONTRASEÑA = "root";

    public static Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Cargar el driver MySQL
            Connection conn = DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);
            System.out.println("¡Conexión exitosa a la base de datos!");
            return conn;
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el driver JDBC.");
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    // Método main para probar la conexión directamente
    public static void main(String[] args) {
        Connection conn = conectar();
        if (conn != null) {
            System.out.println("Base de datos lista para consultas.");
        } else {
            System.out.println("No se pudo establecer la conexión.");
        }
    }
}